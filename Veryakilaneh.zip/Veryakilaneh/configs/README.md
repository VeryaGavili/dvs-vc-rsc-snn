# configs

YAML files that define every run. The code reads them; it does not contain hard-coded values.

- `cameras/` one file per sensor. It sets the sensor size, the input file, the bins, and the pixel-group size.
  - `gen1_240x304.yaml` is the Gen1 event-cube setup. It is runnable.
  - `genx320_320x320.yaml` is the GenX320 setup. It validates, but its loader is not written yet.
- `networks/` one file per network. It sets populations, synapses, kernels, templates, timing, neuron constants, group sizes, parameter ranges, gains, sweep pairs and output options.
  - `vc_rsc_v2.yaml` contains the values from the latest `vc_rsc_v2.py`.

Rules:

- `groups.sizes` for a layer must sum to that layer's size, and `synapses.rsc_fanin` must sum to `syn_per_neuron`. `validate()` checks both.
- A parameter range is either one `[low, high]` for every group, or one `[low, high]` per group.
- Pixel groups must fit into the sensory L1 neurons: `groups` ≤ `n_L1_sensory × syn_per_neuron`. For GenX320, `group_size` 4 is the smallest that fits.

To add a new camera, copy a camera file and change the sensor size, input, and group size. To try a new network, copy `vc_rsc_v2.yaml` and change the values.
